/*
============================================
; Title:  header-test.js
; Author: Professor Krasso 
; Date:   25 June 2017
; Description: Displays a formatted header
;===========================================
*/

const header = require('./header.js');

console.log(header.display("Robert", "Frost", "Week 2"));
