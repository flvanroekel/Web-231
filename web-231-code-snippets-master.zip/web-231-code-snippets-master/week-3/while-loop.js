/*
============================================
; Title:  while-loop.js
; Author: Professor Krasso
; Date:   25 June 2017
; Description: Displays numbers 0-9
;===========================================
*/

// variable
let index = 0;

while (index < 10) {
  console.log(index);
  index++;
}
