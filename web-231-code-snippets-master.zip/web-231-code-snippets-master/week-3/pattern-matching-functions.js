/*
============================================
; Title:  pattern-matching-functions.js
; Author: Professor Krasso
; Date:   25 June 2017
; Description: Displays true or false
;===========================================
*/

// if...else
if (2 > 3) {
  console.log(false);
} else {
  console.log(true);
}
