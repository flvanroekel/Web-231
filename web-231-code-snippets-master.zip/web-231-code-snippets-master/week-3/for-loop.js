/*
============================================
; Title:  for-loop.js
; Author: Professor Krasso
; Date:   25 June 2017
; Description: Displays numbers 0-9
;===========================================
*/

// for loop
for (let x = 0; x < 10; x++) {
  console.log(x);
}
