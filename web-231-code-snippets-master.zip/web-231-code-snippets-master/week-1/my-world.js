/*
============================================
; Title:  my-world.js
; Author: Professor Krasso
; Date:   30 November 2018
; Description: Displays message to the console window
;===========================================
*/

let lastName = 'Krasso'
console.log('You are now in ' + lastName + '\'s world!')
