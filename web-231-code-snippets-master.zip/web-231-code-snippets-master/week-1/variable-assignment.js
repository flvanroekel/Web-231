/*
============================================
; Title:  hello-world.js
; Author: Professor Krasso
; Date:   25 June 2017
; Description: Demonstrates how to assign and output variable values
;===========================================
*/

// variables
const firstName = 'Robert'
const lastName = 'Frost'

console.log('Hello, ' + firstName + ' ' + lastName + '!')


