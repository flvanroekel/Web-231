/*
============================================
; Title:  hello-world.js
; Author: Professor Krasso
; Date:   25 June 2017
; Description: Demonstrates how to assign and output variable values
;===========================================
*/

// variables
const dogName = 'Sam'
const dogColor = 'Black'
const catName = 'Kitty'
const catColor = 'White'
const birdName = 'Rocky'
const birdColor = 'Grey'

// output
console.log('Animal Name: ' + dogName)
console.log('Animal Color: ' + dogColor)
console.log('Animal Name: ' + catName)
console.log('Animal Color: ' + catColor)
console.log('Animal Name: ' + birdName)
console.log('Animal Color: ' + birdColor)
