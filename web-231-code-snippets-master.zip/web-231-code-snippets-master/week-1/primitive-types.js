/*
============================================
; Title:  hello-world.js
; Author: Professor Krasso
; Date:   25 June 2017
; Description: Demonstrates how to assign and output variable values
;===========================================
*/

// variable
let car

// variable assignment
car = "Mustang"

// output 
console.log(car);
