/*
  Expected output:
    
  First name
  Last name
  Age
  Street
  City
  State
  Zip code
*/ 
