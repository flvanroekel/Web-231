/*
============================================
; Title:  hello-world.js
; Author: Professor Krasso
; Date:   25 June 2017
; Description: Displays message to the console window
;===========================================
*/

console.log("Hello World!");
